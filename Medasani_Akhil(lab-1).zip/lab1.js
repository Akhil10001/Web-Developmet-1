
const questionOne= function questionOne(arr)
{
    let c=true;
    let check=new Object();
    if(arr && arr.length>0){
 for(let i=0;i<arr.length;i++)
 {
    arr[i]=(Math.abs(Math.pow(arr[i],2)-7))
    for(let j=2;j<arr[i];j++)
    {
        if(arr[i]%j==0)
        {
            c=false;
            break;   
        }
    }
        check[arr[i]]=c;
        c=true;
 }
}
return check;
}

const questionTwo= function questionTwo(arr)
{
let original_array=[];
if(arr.length>0){
for(let i=0;i<arr.length;i++)
{

    if( original_array.indexOf(arr[i])==-1)
    {
            original_array.push(arr[i]);
    }
}
}
return original_array;
}


const questionThree =function questionThree(str)
{

    let anagram=new Object();

    for(let s of str)
    {
        let key=s.split('').sort().join('');
        if(anagram[key])
        {
            anagram[key].push(s);
        }
        else{
            anagram[key]=[s];
        }
    }
    for(let key in anagram)
    {
      anagram[key]= duplicat_check(anagram[key]);
        if(anagram[key].length<=1)
        {
                delete anagram[key];
        }
        
    }
return anagram;
}


const questionFour = function questionFour(num1, num2, num3)
{
    let result=Math.floor((factorial(num1)+factorial(num2)+factorial(num3))/((num1+num2+num3)/3));
    
    return result;
}

function factorial(number)
{
    let fact=1;
    for(let i=number;i>0;i--)
    {
        fact=fact*i;
    }
    return fact;
}
 
function duplicat_check(arr)
{
let original_array=[];
if(arr.length>0){
for(let i=0;i<arr.length;i++)
{

    if( original_array.indexOf(arr[i])==-1)
    {
            original_array.push(arr[i]);
    }
}
}
return original_array;
}

module.exports = {
    firstName: "Akhil", 
    lastName: "Medasani", 
    studentId: "10478655",
    questionOne,
    questionTwo,
    questionThree,
    questionFour
};