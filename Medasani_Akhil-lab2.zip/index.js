const arrayUtils = require("./arrayUtils");
const stringUtils = require("./stringUtils");
const objUtils = require("./objUtils");


//Arrays first question

try {
    // Should Pass
    const average = arrayUtils.average([[1,3], [2,4,5]]);
    console.log('average passed successfully');
 } catch (e) {
    console.error('average failed test case');
 }

 try {
    // Should Fail
    const average = arrayUtils.average(["banana"]);
    console.error('average did not error');
 } catch (e) {
    console.log('average failed successfully');
 }



//Arrays second question
 try {
    // Should Pass
    const modeSquared = arrayUtils.modeSquared([1, 2, 3, 3, 4]);
    console.log('modeSquared passed successfully');
 } catch (e) {
    console.error('modeSquared failed test case');
 }

 try {
    // Should Fail
    const modeSquared = arrayUtils.modeSquared("banana");
    console.error('modeSquared did not error');
 } catch (e) {
    console.log('modeSquared failed successfully');
 }



 //Array third question

 try {
    // Should Pass
    const medianElement = arrayUtils.medianElement([5, 6, 7]);
    console.log('medianElement passed successfully');
 } catch (e) {
    console.error('medianElement failed test case');
 }

 try {
    // Should Fail
    const medianElement = arrayUtils.medianElement(5, 6, 7);
    console.error('medianElement did not error');
 } catch (e) {
    console.log('medianElement failed successfully');
 }




 //Array fourth question 



 try {
    // Should Pass
    const merge = arrayUtils.merge([1, 2, 3], [3, 1, 2]);
    console.log('merge passed successfully');
 } catch (e) {
    console.error('merge failed test case');
 }

 try {
    // Should Fail
    const merge = arrayUtils.merge([null, null, null], [null, null, null]);
    console.error('merge did not error');
 } catch (e) {
    console.log('merge failed successfully');
 }






 //string first question


 try {
    // Should Pass
    const sortString = stringUtils.sortString('123 FOO BAR!');
    console.log('sortString passed successfully');
 } catch (e) {
    console.error('sortString failed test case');
 }

 try {
    // Should Fail
    const sortString = stringUtils.sortString();
    console.error('sortString did not error');
 } catch (e) {
    console.log('sortString failed successfully');
 }





//string second question


 try {
    // Should Pass
    const replaceChar = stringUtils.replaceChar("Daddy", 2);
    console.log('replaceChar passed successfully');
 } catch (e) {
    console.error('replaceChar failed test case');
 }

 try {
    // Should Fail
    const replaceChar = stringUtils.replaceChar("foobar", 0);
    console.error('replaceChar did not error');
 } catch (e) {
    console.log('replaceChar failed successfully');
 }




 
 //string third question


 
 try {
    // Should Pass
    const mashUp = stringUtils.mashUp("Patrick", "Hill", "$");
    console.log('mashUp passed successfully');
 } catch (e) {
    console.error('mashUp failed test case');
 }

 try {
    // Should Fail
    const mashUp = stringUtils.mashUp("Patrick", "");
    console.error('mashUp did not error');
 } catch (e) {
    console.log('mashUp failed successfully');
 }



 // objects first question


 try {
    // Should Pass

    const first = { x: 2, y: 3};
    const second = { a: 70, x: 4, z: 5 };
    const third = { x: 0, y: 9, q: 10 };
    const computeObjects = objUtils.computeObjects([first, second], x => x * 2);
    console.log('computeObjects passed successfully');
 } catch (e) {
    console.error('computeObjects failed test case');
 }

 try {
    // Should Fail
    const computeObjects = objUtils.computeObjects([],x => x * 2);
    console.error('computeObjects did not error');
 } catch (e) {
    console.log('computeObjects failed successfully');
 }



 //objects second question



 try {
    // Should Pass

    const first = {a: 2, b: 4};
    const second = {a: 5, b: 4};
    const third = {a: 2, b: {x: 7}};
    const fourth = {a: 3, b: {x: 7, y: 10}};
    const commonKeys = objUtils.commonKeys(third, fourth);
    console.log('commonKeys passed successfully');
 } catch (e) {
    console.error('commonKeys failed test case');
 }

 try {
    // Should Fail
    const commonKeys = objUtils.commonKeys([],);
    console.error('commonKeys did not error');
 } catch (e) {
    console.log('commonKeys failed successfully');
 }



 //objects third question


 try {
    // Should Pass

    const flipObject = objUtils.flipObject({ a: 3, b: 7, c: 5 });
    console.log('flipObject passed successfully');
 } catch (e) {
    console.error('flipObject failed test case');
 }

 try {
    // Should Fail
    const flipObject = objUtils.flipObject({});
    console.error('flipObject did not error');
 } catch (e) {
    console.log('flipObject failed successfully');
 }
