function computeObjects(objects, func)          //Eigth question code
{

checkifArray(objects,func);

let object;
let original_obj;
let check=false;
original_obj=objects[0];
for(let i=1;i<objects.length;i++)
{

       objects[i]=duplicate_check(original_obj,objects[i]);
    original_obj=Object.assign(original_obj,objects[i]);
    
    
}

for(let x in original_obj)
{
    original_obj[x]=func(original_obj[x]);
}
return original_obj;
}

function duplicate_check(original_obj,object)
{
    for(let element1 in original_obj )
    {
        for(let element2 in object)
        {
            if(element1==element2)
            {
                original_obj[element1]=original_obj[element1]+object[element2];
                delete object[element2];
            }
        }

    }
   return object;
}


function checkifArray(objects,func)
{
    if(!Array.isArray(objects))
    {
        throw 'objects is not an array';
    }
    else if(!objects.length>0)
    {
        throw 'object array should not be empty'
    }
    
    for(let i=0;i<objects.length;i++)
    {
        if(typeof objects[i]!=='object' || objects[i]==null || Array.isArray(objects[i]))
        {
                throw 'Enter only objects';
        }
        else if(Object.keys(objects[i]).length<=0)
        {
            throw 'object should not be empty';
        }
        checkobject(objects[i]);

    }

    if(!isFunction(func))
    {
        throw 'please enter a proper function';
    }

}

function isFunction(functionToCheck) {
    return functionToCheck && {}.toString.call(functionToCheck) === '[object Function]';
   }
function checkobject(object)
{
for(let key in object)
{
    if(typeof object[key]!== 'number')
            {
                throw 'value inside object is not valid';
            }
}

}








function commonKeys(obj1, obj2)             //   ninth question code
{
    checkifobject(obj1);
    checkifobject(obj2);
    let new_obj={};
for(let key1 in obj1)
{
    for(let key2 in obj2)
    {
        if(key1==key2)
        {
            if(isobject(obj1[key1]) && isobject(obj2[key2]))
            {
                   new_obj[key1]= commonKeys(obj1[key1],obj2[key2]);          
            }
            else if(obj1[key1]==obj2[key2])
        {
            new_obj[key1]=obj1[key1];
        }
        }
        
    }
}
return new_obj;
}

function isobject(obj)
{
    return(typeof obj==='object');
}



function checkifobject(obj)
{
    if(typeof obj== 'undefined')
    {
        throw 'please give argument';
    }
    else if(typeof obj!=='object' || obj==null || Array.isArray(obj))
    {
        throw 'Enter only objects';
    }
}










function flipObject(object)             // tenth question code
{
checktheobject(object);
let newobj={};

for(let [key, value] of Object.entries(object))
{

    if(Array.isArray(value))
    {
        for(let v in value)
        {
            newobj[value[v]]=key;
        }
    }

    
    else if(isobj(value))
    {
        newobj[key]=flipObject(value)

    }
    else 
    {
        newobj[value]=key;
    }


}
return newobj;
}
function isobj(obj)
{
    return(typeof obj==='object');
}

function checktheobject(object)
{
     if(typeof object!=='object' || object==null || Array.isArray(object))
    {
        throw 'Enter only objects';
    }
    else if(Object.keys(object).length<=0)
    {
        throw 'object should not be empty';
    }
}




module.exports = {
    firstName: "Akhil", 
    lastName: "Medasani", 
    studentId: "10478655",
    computeObjects,
    commonKeys,
    flipObject
};