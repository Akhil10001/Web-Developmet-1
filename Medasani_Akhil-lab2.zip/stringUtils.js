function sortString(string)    //question 5 code
{
    check_string(string);

    let character="";
    let small_letter="";
    let numbers="";
    let special="";
    let spaces="";
    let capital_letter="";

for(let i=0;i<string.length;i++)
{
    character=string.charAt(i);

    if(character>='a' && character<='z')
    {
        
        small_letter=small_letter+character;

    }
    else if(character>='0' && character<='9')
{
    numbers=numbers+character;
}

else if(character.charCodeAt(0)>=33 && character.charCodeAt(0)<=47 || 
character.charCodeAt(0)>=58 && character.charCodeAt(0)<=64 ||
character.charCodeAt(0)>=91 && character.charCodeAt(0)<=96 ||
character.charCodeAt(0)>=123 && character.charCodeAt(0)<=126){

    special=special+character;
}
else if(character.charCodeAt(0)==32){
spaces=spaces+character;
}

else if(character>='A'&& character<='Z')
{

    capital_letter=capital_letter+character;
}

}

small_letter=small_letter.split('').sort().join('');
capital_letter=capital_letter.split('').sort().join('');
numbers=numbers.split('').sort().join('');
special=special.split('').sort().join('');

string=capital_letter+small_letter+special+numbers+spaces

return string; 
}












  function replaceChar(string,idx)        // sixth question code
  {
      check_idx(string,idx);
  let character="";
  let count=0;
  let prev,next;
  
   character=string.charAt(idx);
  
   if(idx>0 && idx<=string.length-2)
   {
      prev=string.charAt(idx-1);
      next=string.charAt(idx+1);
   }
  
  
   for(let i=1;i<string.length;i++)
   {
  
      if(i!=idx && string.charAt(i)==character)
      {
          if(count%2==0)
          {
              string=replaceAt(string,i,prev)
              count++;
          }
          else{
              string=replaceAt(string,i,next)
              count++;
          }
  
      }
  
   }
  
  return string; 
  }
  function replaceAt(string,index, replace) {
  
      return string.substring(0, index) + replace + string.substring(index+1,string.length);
  }
  
  
  function check_idx(string,idx)
  {
      check_string(string)
       if(typeof idx!== 'number')
      {
          throw 'idx should be a number'
      }
      else if(idx>=string.length)
      {
          throw 'idx is out of bound'
      }
      else if(idx<=0 || idx>string.length-2)
      {
          throw 'give an index that is within the necessary limit'
      }
      
  
  }






  function mashUp(string1, string2, char)                 //seventh question code
  {
      check_string(string1);
      check_string(string2);
      check_string(char);
  
  let string="";
      if(string1.length==string2.length)
      {
         
          string=mashitup(string1,string2);
  
      }
      else if(string1.length<string2.length)
          {
              let length_of_string1=string1.length;
              let length_of_string2=string2.length;
              let length=length_of_string2-length_of_string1;
  
              for(let i=0;i<length;i++)
              {
                  string1=string1+char;
              }
              string=mashitup(string1,string2);
          }
          else if(string2.length<string1.length)
          {
              let length_of_string1=string1.length;
              let length_of_string2=string2.length;
              let length=length_of_string1-length_of_string2;
  
              for(let i=0;i<length;i++)
              {
                  string2=string2+char;
              }
              string=mashitup(string1,string2);
          }
  
  return string;
  }
  
  
  function mashitup(string1,string2)
  {
      let string="";
      for(let i=0;i<string1.length;i++)
      {
         string=string+string1.charAt(i)+string2.charAt(i); 
      }
      return string;
  }


function check_string(string)           //common code for strings
{
    if (!string) {
        throw 'please enter a string'
    }
    else if(!isString(string))
    {
        throw 'input is not a string'
    }
    else if(string.length<0)
    {
        throw 'please enter a string that is greater than zero'
    }
    else if(check_for_spaces(string))
    {
        throw 'string should contain more than spaces'
    }
}

function check_for_spaces(string)               //common code for strings
{
    let count=0;
    for(let i=0;i<string.length;i++)
    {
        if(string.charCodeAt(i)==32)
        {
            count++;
        }
    }
    if(count==string.length)
    {
        return true;
    }
    else{
        return false;
    }
}

function isString(x)                    //common code for strings
{
    return Object.prototype.toString.call(x) === "[object String]"
  }

module.exports = {
    firstName: "Akhil", 
    lastName: "Medasani", 
    studentId: "10478655",
    sortString,
    replaceChar,
    mashUp
};