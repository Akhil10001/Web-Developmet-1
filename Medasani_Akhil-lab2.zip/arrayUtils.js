

function average(arrays)                /// First question code
{

checkArray(arrays);
let a=0;
let count=0;
let total_sum=0;

for(let i=0;i<arrays.length;i++)
{
    let sum=0;
    if(!arrays[i].length>0)
    {
        throw 'internal array is empty'
    }
    
    for (let j=0;j<arrays[i].length;j++)
    {
        check_number_in_array(arrays[i][j])
    
        sum=sum+arrays[i][j];
        count++;
    }
    total_sum=total_sum+sum;
}
a=Math.round(total_sum/count);
return a;
}







function modeSquared(array)  /// Second question code
{
    checkArray(array)

let sort=new Object();

for(let i=0;i<array.length;i++)
{
    check_number_in_array(array[i]);
    let num=array[i];
    let count=0;
    for(let j=i;j<array.length;j++)
    {
        check_number_in_array(array[j]);
            if(num==array[j])
            {
                count++;
            }
    }
    if(!sort[array[i]])
    {
        sort[array[i]]=count;
    }
}

let modes=mode(sort);
let sum_of_modes=0;

if(modes.length==0)
{
    return 0;
}
else if(modes.length>=1)
{
    for(i=0;i<modes.length;i++)
    {
        sum_of_modes=sum_of_modes+Math.pow(modes[i],2)      
    }
}

return sum_of_modes;
}

function mode(sort)
{

    let big=1,sum=[],value;
for(let key in sort)
{
    if(sort[key]>big)
    {
        big=sort[key];
        value=key;
    }
}
if(big>1)
{
    sum.push(value);
    for(let key in sort)
{
    if(big==sort[key] && key!=value)
    {
        sum.push(key)
    }
}
}
return sum;
}









function medianElement(array)                           //third question code
{
  checkArray(array)
  
checking_array_number(array)

let index;
let copyarray = Array.from(array);
let newobject={};

copyarray=copyarray.sort();

if(copyarray.length%2!=0)
{
  let array_index=Math.floor((copyarray.length)/2);
  let median=copyarray[array_index];

  for(let i=0;i<array.length;i++)
  {
    if(median==array[i])
    {
      index=i;
    }
  }
newobject[median]=index;

}
else
{
  let second_element=copyarray[Math.floor(copyarray.length/2)]
  let first_element=copyarray[Math.floor(copyarray.length/2)-1]
  let first_index=array.indexOf(first_element);
  let second_index=array.indexOf(second_element);

  let median=(first_element+second_element)/2;

if(first_index>second_index)
{
  index=first_index;
}
else if(second_index>first_index)
{
  index=second_index;
}
else if(first_index==second_index)
{
  index=first_index;
}
newobject[median]=index;

}


return newobject;

}

function checking_array_number(array)
{
  for(let i=0;i<array.length;i++)
  {
    if(typeof array[i]!== 'number') 
    {
       throw 'internal array not a number error'
    }  
  }
}











function merge(arrayOne, arrayTwo)          //fourth question code
{
    checkArray(arrayOne);
    checkArray(arrayTwo);

    let capital_letter=[];
    let small_letter=[];
    let numbers=[];
    
returned_array=temp_merge(arrayOne, arrayTwo)

for(i=0;i<returned_array.length;i++)
{
    
    check_character(returned_array[i]);
   
    
    if(returned_array[i]>='A' && returned_array[i]<='Z')
    {
        capital_letter.push(returned_array[i]);
    }
    
    else if(returned_array[i]>='a' && returned_array[i]<='z')
    {
        small_letter.push(returned_array[i]);
    }
    else if(!isNaN(returned_array[i]))
    {
        numbers.push(returned_array[i]);
    }

}
capital_letter=capital_letter.sort();
small_letter=small_letter.sort();
numbers=numbers.sort();

let w=0,x=0,y=0,z=0;

if(small_letter.length>0)
{
while(x<small_letter.length)
{
    returned_array[w]=small_letter[x];
    w++;
    x++;

}
}

if(capital_letter.length>0)
{
while(y<capital_letter.length)
{
    returned_array[w]=capital_letter[y];
    w++;
    y++;

}
}

if(numbers.length>0)
{
while(z<numbers.length)
{
    returned_array[w]=numbers[z];
    w++;
    z++;

}
}

return returned_array;
}


function temp_merge(arrayOne,arrayTwo)
{
    let j=arrayOne.length;
    for(let i=0;i<arrayTwo.length;i++)
    {
        arrayOne[j]=arrayTwo[i];
        j++;
    }
return arrayOne;
}


function check_character(char)
{
    if(isNaN(char) && ((/[a-zA-Z]/).test(char)== false)) 
    {
       throw 'input is neither a number nor a character';
    }  
    else if(typeof char==='boolean')
    {
        throw 'input should not be boolean';
    }
    else if(typeof char==='undefined')
    {
        throw 'input should not be undefined';
    }
    else if(char==null)
    {
        throw 'input should not be null';
    }

}




function checkArray(array)      // code for checking array at start
{

    if(typeof array== 'undefined')
    {
        throw 'please enter an array';
    }
    if(!Array.isArray(array))
    {
        throw 'please do not enter anything but an array';
    }
    if(!array.length>0)
    {
        throw 'array is empty';
    }
}


function check_number_in_array(num)          // code for checking array at start
{
    if(typeof num!== 'number') 
    {
       throw 'internal array not a number error'
    }  
}



module.exports = {
    firstName: "Akhil", 
    lastName: "Medasani", 
    studentId: "10478655",
    average,
    modeSquared,
    medianElement,
    merge
};